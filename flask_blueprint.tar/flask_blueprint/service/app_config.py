'''
환경 변수 클레스
맴버 변수로 정의
'''
class FalskWebConfig(object):
  DB_URL      = 'localhost'
  DB_USER     = 'root'
  DB_PWD      = 'root'
  DB_DATABASE = 'pythondb'
  DB_CHARSET  = 'utf8'
  DB_LOG_FLAG = 'True'
  DB_PORT     = 3306