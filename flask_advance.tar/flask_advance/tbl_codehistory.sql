--종목 이름을 가지고 종목 정보 가져오기
select code,name,cur from tbl_trade
where name like '%삼성%';